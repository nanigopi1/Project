import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  dataone:any[];
  res:boolean;availability:boolean=true ;
  
  constructor(private userService:UserService,private productService:ProductserviceService) { }

  ngOnInit() {
    return this.userService.getdata().subscribe((data:any)=>{this.dataone=data;
  
  })
}
 

  addToCart(prod){
    console.log(".ts angular")
    console.log(prod.proId);
    return this.userService.addToCart(prod.proId)
  
  }
  addToWishlist(prod){
    return this.userService.createWishList(prod.proId);
  }
  
  getAvaliability(availability){
    if(availability==="Yes"){
      return true;
    }
    else{
      return false;
    }

  }
}
