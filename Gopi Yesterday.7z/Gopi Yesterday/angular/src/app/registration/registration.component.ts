import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

 
  model:any={};
  result:number;

  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
  }
  addUser():any{
    console.log(this.model);
    this.userService.addUser(this.model).subscribe((data:number)=>{this.result=data;
    console.log(this.result);
    if(this.result==1){
      alert("Registration Successfull")
      this.router.navigate(['/login']);
    }
    else if(this.result==2){
      alert("Admin Rights are violated...you cannot register as admin");
    }
    else{
      alert("User Already Exist")
    }
  });
} 
}  
  