import { Injectable } from '@angular/core';

import { HttpClient } from '../../node_modules/@angular/common/http';
import { Router } from '../../node_modules/@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  currentUser:string;
  constructor(private httpClient:HttpClient,private router:Router) { }
  
  getProductsByCategory(name:String){
    console.log(name)
    return this.httpClient.get("http://localhost:9632/product/getByCategory/"+name);


  }
  
  search(){
    this.router.navigate(['/search']);
  }
  searchByName(search:string){
    return this.httpClient.get("http://localhost:9632/product/getByCategoryandPrice?search="+search);
    }
    getCartProducts(){
      return this.httpClient.get("http://localhost:9632/cartlist/getAll");
    }
    addToCart(id:String){
      console.log("User Mail"+this.currentUser);
    
      console.log("in service"+id)

      return this.httpClient.get("http://localhost:9632/cartlist/cart1?productId="+id).subscribe((data)=>{
        console.log(data);
      });
    }
    getPrice(){
      return this.httpClient.get("http://localhost:9632/cartlist/price");

    }
    getAvailability(id){
      return this.httpClient.get("http://localhost:9632/product/availability?productId="+id)
    }
    

 
}
