import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ProductsComponent } from './products/products.component';
import { CartComponent } from './cart/cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { ProductListComponent } from './product/product-list.component';
import { LogoutComponent } from './logout/logout.component';
import { SearchComponent } from './search/search.component';
import { SearchBymobilesComponent } from './searchByMobiles/search-bymobiles.component';
import { SearchbylapComponent } from './searchbylaptops/searchbylap.component';
import { SearchbyheadphonesComponent } from './searchbyheadphones/searchbyheadphones.component';
import { ConfirmEqualValidatorDirective } from "./registration/confirm-equal-validator.directive";

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    ProductsComponent,
    CartComponent,
    WishlistComponent,
    ProductListComponent,
    LogoutComponent,
    SearchComponent,
    SearchBymobilesComponent,
    SearchbylapComponent,
    SearchbyheadphonesComponent,
    ConfirmEqualValidatorDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
