import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-searchbylap',
  templateUrl: './searchbylap.component.html',
  styleUrls: ['./searchbylap.component.css']
})
export class SearchbylapComponent implements OnInit {

  products: any[]=[];
  products1: any[]=[];
  constructor(private productService:ProductserviceService,private router:Router,private userService:UserService) { }
  name:String;
  searchName=true;
  searchId=false;
  searchterm:any;
  
  private _searchterm:string;
  searchterm1:any;
  ngOnInit() {
    console.log("In Search")
    this.name="laptop";
    console.log(this.name)
    this.productService.getProductsByCategory(this.name).subscribe((data:any)=>{this.products=data;console.log(this.products1)});

  
  }
  addToCart(prod){
    console.log(".ts angular")
    console.log(prod.proId);
    return this.userService.addToCart(prod.proId)
  
  }
  addToWishlist(prod){
    return this.userService.createWishList(prod.proId);
  }

}
