package com.cg.cataloguesystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.cataloguesystem.bean.ProductDetails;

@Repository
public class ProductDetailsDaoImpl implements ProductDetailsDao {
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public ProductDetails createCartDetails(ProductDetails productlist) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(productlist);
	}

	@Override
	public List<ProductDetails> getAllProduct() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(ProductDetails.class);
	}

	@Override
	public ProductDetails getByProductId(int id) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(id, ProductDetails.class);
	}

	@Override
	public ProductDetails getByName(String name) {
		Query query=Query.query(Criteria.where("proName").is(name));
		ProductDetails e=mongotemplate.findOne(query, ProductDetails.class);
		return e;
	}

	@Override
	public List<ProductDetails> getByProductCategory(String category) {
		// TODO Auto-generated method stub
		List<ProductDetails> products=mongotemplate.findAll(ProductDetails.class);
		List<ProductDetails> p=new ArrayList<ProductDetails>();
		System.out.println("in service"+category);
		for(ProductDetails pcategory:products) {
			if(pcategory.getProCategory().equalsIgnoreCase(category))
				p.add(pcategory);
		}
		return p;
	}

	@Override
	public List<ProductDetails> getByProductPrice(String price) {
		// TODO Auto-generated method stub
		List<ProductDetails> products=mongotemplate.findAll(ProductDetails.class);
		List<ProductDetails> p=new ArrayList<ProductDetails>();
		
		for(ProductDetails product:products) {
			if(product.getProPrice().equals(price))
				p.add(product);
		}
		return p;
	}

	@Override
	public List<ProductDetails> searchByCategoryandPrice(String search) {
		// TODO Auto-generated method stub
		List<ProductDetails> products=mongotemplate.findAll(ProductDetails.class);
		List<ProductDetails> p=new ArrayList<ProductDetails>();
		for(ProductDetails product:products) {
			if(product.getProPrice().equals(search))
				p.add(product);
			else if(product.getProCategory().equalsIgnoreCase(search))
				p.add(product);
			else if(product.getProName().equalsIgnoreCase(search))
				p.add(product);
		}
		return p;
	}

	@Override
	public boolean getAvailability(String id) {
		// TODO Auto-generated method stub
		ProductDetails prod=mongotemplate.findById(id, ProductDetails.class);
		if(prod.getAvailability().equalsIgnoreCase("yes"))
		return true;
		else {
			return false;
		}
	}

}
