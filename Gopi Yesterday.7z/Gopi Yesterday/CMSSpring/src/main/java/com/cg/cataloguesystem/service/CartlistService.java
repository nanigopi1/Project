package com.cg.cataloguesystem.service;

import java.util.List;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;

public interface CartlistService {
	CartDetails createCartDetails(CartDetails cartlist);
	List<CartDetails> getAllCart();
        CartDetails getByIdInCartList(int id);
        void addToCart12(String id);
        boolean addToCart1(String prodId);
        boolean addToCart(String prodId,String user);
        public Double price();
}
