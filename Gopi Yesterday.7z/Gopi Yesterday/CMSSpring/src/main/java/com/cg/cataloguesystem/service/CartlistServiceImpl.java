package com.cg.cataloguesystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.dao.CartlistDao;

@Service
public class CartlistServiceImpl implements CartlistService {
	@Autowired
	CartlistDao cartlistdao;

	@Override
	public CartDetails createCartDetails(CartDetails cartlist) {
		// TODO Auto-generated method stub
		System.out.println("In cart Service");
		return cartlistdao.createCartDetails(cartlist);
	}
	@Override
	public void addToCart12(String id) {
		// TODO Auto-generated method stub
		System.out.println("In cart Service");
		cartlistdao.addToCart12(id);
	}

	@Override
	public List<CartDetails> getAllCart() {
		// TODO Auto-generated method stub
		return cartlistdao.getAllCart();
	}

	@Override
	public CartDetails getByIdInCartList(int id) {
		// TODO Auto-generated method stub
		return cartlistdao.getByIdInCartList(id);
	}
	@Override
	public boolean addToCart1(String prodId) {
		// TODO Auto-generated method stub
		return cartlistdao.addToCart1(prodId);
	}
	@Override
	public Double price() {
		// TODO Auto-generated method stub
		return cartlistdao.price();
	}
	
	@Override
	public boolean addToCart(String prodId, String user) {
		// TODO Auto-generated method stub
		return cartlistdao.addToCart(prodId,user);
	}

}
