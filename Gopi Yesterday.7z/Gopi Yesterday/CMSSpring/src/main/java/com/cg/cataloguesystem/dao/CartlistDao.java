package com.cg.cataloguesystem.dao;

import java.util.List;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;

public interface CartlistDao {
	CartDetails createCartDetails(CartDetails cartlist);
	List<CartDetails> getAllCart();
	 CartDetails getByIdInCartList(int id);
	 public Double price();
	void addToCart12(String id); 
	 boolean addToCart1(String productId);
	 boolean addToCart(String productId,String user);
}
