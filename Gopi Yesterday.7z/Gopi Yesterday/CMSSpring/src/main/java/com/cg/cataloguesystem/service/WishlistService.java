package com.cg.cataloguesystem.service;

import java.util.List;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;

public interface WishlistService {
	WishlistDetails createWishlist(String id);
    List<WishlistDetails> getAllWishlist();
    WishlistDetails getByIdInWhishList(int id);
   
	


}
