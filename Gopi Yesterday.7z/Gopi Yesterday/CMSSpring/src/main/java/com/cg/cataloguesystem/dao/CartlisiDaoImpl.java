package com.cg.cataloguesystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.bean.UserDetails;

@Repository
public class CartlisiDaoImpl implements CartlistDao  {
	@Autowired
	MongoTemplate mongotemplate;
	@Autowired
	ProductDetailsDao prodao;
	UserDetails customer;


	@Override
	public CartDetails createCartDetails(CartDetails cartlist) {
		System.out.println("In cart dao");
		// TODO Auto-generated method stub
		return mongotemplate.insert(cartlist);
	}

	/*
	 * @Override public void addToCart1(String id) { List<ProductDetails>
	 * prolist=prodao.getAllProduct(); Query query=new Query();
	 * query.addCriteria(Criteria.where("proId").is(id)); List<ProductDetails>
	 * productDetails=mongotemplate.find(query, ProductDetails.class); CartDetails
	 * cart=new CartDetails();
	 * 
	 * cart.setQuantity(3); cart.setTotalPrice(0.0);
	 * cart.setProductdetails1(productDetails); mongotemplate.insert(cart); }
	 */
	@Override
	public List<CartDetails> getAllCart() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(CartDetails.class);
	}

	@Override
	public CartDetails getByIdInCartList(int id) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(id,CartDetails.class);
	}
	@Override
	public boolean addToCart1(String productId) {
		// TODO Auto-generated method stub
		Query query=new Query();
		CartDetails cart=new CartDetails();
		System.out.println(productId);
		
					if(cart.getProductdetails1()==null) 
					{
						cart.setProductdetails1(new ArrayList<ProductDetails>());
					}
					List<ProductDetails> productList=cart.getProductdetails1();
		
		//to update the product quantity
		query.addCriteria(Criteria.where("_id").is(productId));
		ProductDetails product=mongotemplate.findOne(query,ProductDetails.class);
		if(product==null)
			return false;

		if(product.getProId()==null) 
		{
			return false;
		}		
		ProductDetails productInformation = new ProductDetails();
		productInformation.setProId(product.getProId());
		productInformation.setProName(product.getProName());
		productInformation.setProCategory(product.getProCategory());
		productInformation.setImageUrl(product.getImageUrl());
		productInformation.setProDesc(product.getProDesc());
		productInformation.setAvailability(product.getAvailability());
		productInformation.setProPrice(product.getProPrice());
		productList.add(productInformation);
		cart.setProductdetails1(productList);
		mongotemplate.save(cart);
		return true;
	}
	
	public Double price() {
		Double price=0.0,proprice;
		List<CartDetails> cart=mongotemplate.findAll(CartDetails.class);
		
		for (CartDetails cartDetails : cart) {
		List<ProductDetails> product=cartDetails.getProductdetails1();
		for (ProductDetails prod:product) {
			proprice=Double.parseDouble(prod.getProPrice());
			price+=proprice;
			cartDetails.setTotalPrice(price);
			
		}
		
			
		}
		
	
		System.out.println();
	
		
				return price;
	}

	@Override
	public boolean addToCart(String productId, String user) {
		List<UserDetails> details=mongotemplate.findAll(UserDetails.class);
		for (UserDetails userDetails : details) {
			if(userDetails.getEmailId().equals(user)) {
				
				customer=userDetails;
				break;
			}
			else {
				return false;
				
			
		}
		}
		if(customer.getCartdetails()==null) {
			customer.setCartdetails(new CartDetails());
		}
		CartDetails cart1=customer.getCartdetails();
		
		Query query=new Query();
		CartDetails cart=new CartDetails();
		System.out.println(productId);
		
					if(cart.getProductdetails1()==null) 
					{
						cart.setProductdetails1(new ArrayList<ProductDetails>());
					}
					List<ProductDetails> productList=cart.getProductdetails1();
		
		
		query.addCriteria(Criteria.where("_id").is(productId));
		ProductDetails product=mongotemplate.findOne(query,ProductDetails.class);
		if(product==null)
			return false;

		if(product.getProId()==null) 
		{
			return false;
		}		
		ProductDetails productInformation = new ProductDetails();
		productInformation.setProId(product.getProId());
		productInformation.setProName(product.getProName());
		productInformation.setProCategory(product.getProCategory());
		productInformation.setImageUrl(product.getImageUrl());
		productInformation.setProDesc(product.getProDesc());
		productInformation.setAvailability(product.getAvailability());
		productInformation.setProPrice(product.getProPrice());
		productList.add(productInformation);
		cart.setProductdetails1(productList);
		mongotemplate.save(cart);
		return true;
	}
	

	@Override
	public void addToCart12(String id) {
		// TODO Auto-generated method stub
		
	}

}
