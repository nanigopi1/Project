package com.cg.cataloguesystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.cataloguesystem.bean.UserDetails;

@Repository
public class UserlistDaoImpl implements UserlistDao {
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public Integer createIncomeTax(UserDetails userlist) {
		
		// TODO Auto-generated method stub
		if(userlist.getUserType().equalsIgnoreCase("admin")) {
		if(userlist.getName().equalsIgnoreCase("admin")) {
			System.out.println("Hiii in admin");
		mongotemplate.insert(userlist);
		return 1;
		}
		return 2;
	}
		else {
			List<UserDetails> users=mongotemplate.findAll(UserDetails.class);
			System.out.println("in user if");
			for(UserDetails user:users) {
				if(user.getName().equalsIgnoreCase(userlist.getName())) {
					return 3;
				}
				
				}
			System.out.println("in user else");
			mongotemplate.insert(userlist);
				return 1;
				
			
			
		}
	}

	@Override
	public List<UserDetails> getAllUser() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(UserDetails.class);
	}

	@Override
	public UserDetails getByUserId(int id) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(id, UserDetails.class);
	}

	@Override
	public List<UserDetails> getByName(String name) {
		// TODO Auto-generated method stub
		List<UserDetails> users=mongotemplate.findAll(UserDetails.class);
		List<UserDetails> u=new ArrayList<UserDetails>();
		for(UserDetails user:users) {
			if(user.getName().equals(name))
				u.add(user);
		}
		return u;
	}

	@Override
	public Integer validateByMailPswd(String mailId, String pswd) {
		// TODO Auto-generated method stub
		Integer value=0;
		String role=" ";
		UserDetails user=mongotemplate.findOne(Query.query(Criteria.where("emailId").is(mailId)),UserDetails.class);
		    if(user==null)
		    {
		    	return value;
		    }
		    else {
		    if(user.getPassword().equals(pswd))
		     	role=user.getUserType();
		    if(role.equals("admin")) {
		    	value=1;
		    	return value;
		    }
		    else if(role.equals("user")) {
		    	value=2;
		    	return value;
		    	}
		    else {
		    	value=0;
		    	return value;
		    }
		}
	}
	}


