package com.cg.cataloguesystem.bean;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="wishlist")
public class WishlistDetails {
	private List<ProductDetails> productdetails;
	public List<ProductDetails> getProductdetails() {
		return productdetails;
	}
	public void setProductdetails(List<ProductDetails> productdetails) {
		this.productdetails = productdetails;
	}
	@Override
	public String toString() {
		return "WishlistDetails [ productdetails=" + productdetails + "]";
	}
	public WishlistDetails(Integer wishlistId, List<ProductDetails> productdetails) {
		super();
		
		this.productdetails = productdetails;
	}
	public WishlistDetails() {
		super();
	}
	

}
