package com.cg.cataloguesystem.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;
import com.cg.cataloguesystem.service.ProductlistService;

@Repository
public class WishlistDaoImpl implements WishlistDao{
	@Autowired
	MongoTemplate mongotemplate;
	@Autowired
	ProductlistService service;

	@Override
	public WishlistDetails createWishlist(String id) {
		// TODO Auto-generated method stub
		List<ProductDetails> details=service.getAllProduct();
		WishlistDetails wish=new WishlistDetails();
		Query query=new Query();
		query.addCriteria(Criteria.where("proId").is(id));
		List<ProductDetails> productDetails=mongotemplate.find(query, ProductDetails.class);
		if(productDetails.isEmpty())
			return null;
		wish.setProductdetails(productDetails);
		return mongotemplate.insert(wish);
	}

	@Override
	public List<WishlistDetails> getAllWishlist() {
		
		return mongotemplate.findAll(WishlistDetails.class);
	}

	@Override
	public WishlistDetails getByIdInWhishList(int id) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(id,WishlistDetails.class);
	}


	
	

	}


