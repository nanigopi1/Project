package com.cg.cataloguesystem.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestParam;

import com.cg.cataloguesystem.bean.UserDetails;

public interface UserlistService {
	Integer createIncomeTax(UserDetails userlist);
	List<UserDetails> getAllUser();
	UserDetails getByUserId(int id);
	List<UserDetails> getByName(String name);
	Integer validateByMailPswd(String mailId,String pswd); 
}
