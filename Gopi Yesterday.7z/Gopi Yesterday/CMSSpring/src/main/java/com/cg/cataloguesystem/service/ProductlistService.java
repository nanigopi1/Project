package com.cg.cataloguesystem.service;

import java.util.List;

import com.cg.cataloguesystem.bean.ProductDetails;

public interface ProductlistService {
	ProductDetails createProductDetails(ProductDetails productlist);
	List<ProductDetails> getAllProduct();
	ProductDetails getByProductId(int id);
	ProductDetails getByName(String name);
	List<ProductDetails> getByProductCategory(String category);
	List<ProductDetails> getByProductPrice(String price);
	List<ProductDetails> searchByCategoryandPrice(String search);
	boolean getAvailability(String id);
}
