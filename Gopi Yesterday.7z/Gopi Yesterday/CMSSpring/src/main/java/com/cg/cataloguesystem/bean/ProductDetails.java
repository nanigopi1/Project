package com.cg.cataloguesystem.bean;




import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="product")
public class ProductDetails {
	@Id
	private String proId;
	private String proName;
	private String proDesc;
	private String proPrice;
	private String proCategory;
	private String imageUrl;
	private String availability;
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getProDesc() {
		return proDesc;
	}
	public void setProDesc(String proDesc) {
		this.proDesc = proDesc;
	}
	public String getProPrice() {
		return proPrice;
	}
	public void setProPrice(String proPrice) {
		this.proPrice = proPrice;
	}
	public String getProCategory() {
		return proCategory;
	}
	public void setProCategory(String proCategory) {
		this.proCategory = proCategory;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	@Override
	public String toString() {
		return "ProductDetails [proId=" + proId + ", proName=" + proName + ", proDesc=" + proDesc + ", proPrice="
				+ proPrice + ", proCategory=" + proCategory + ", imageUrl=" + imageUrl + ", availability="
				+ availability + "]";
	}
	public ProductDetails(String proId, String proName, String proDesc, String proPrice, String proCategory,
			String imageUrl, String availability) {
		super();
		this.proId = proId;
		this.proName = proName;
		this.proDesc = proDesc;
		this.proPrice = proPrice;
		this.proCategory = proCategory;
		this.imageUrl = imageUrl;
		this.availability = availability;
	}
	public ProductDetails() {
		super();
	}
	
	
}
